//
//  LemonRestaurantC2Tests.swift
//  LemonRestaurantC2Tests
//
//  Created by Lavonde Dunigan on 8/5/25.
//

import Testing
@testable import LemonRestaurantC2

struct LemonRestaurantC2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
