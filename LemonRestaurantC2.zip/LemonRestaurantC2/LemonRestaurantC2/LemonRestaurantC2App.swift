//
//  LemonRestaurantC2App.swift
//  LemonRestaurantC2
//
//  Created by Lavonde Dunigan on 8/5/25.
//

import SwiftUI

@main
struct LemonRestaurantC2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
